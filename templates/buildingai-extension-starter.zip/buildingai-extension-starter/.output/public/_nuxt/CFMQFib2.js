import{G as u,H as s}from"#entry";function t(r,i){return u(r)?!1:Array.isArray(r)?r.some(l=>s(l,i)):s(r,i)}export{t as i};
