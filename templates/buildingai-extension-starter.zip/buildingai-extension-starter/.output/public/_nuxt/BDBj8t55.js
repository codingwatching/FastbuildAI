import{_ as e}from"./DlAUqK2U.js";import{d as o,o as r}from"#entry";const c={};function n(t,a){return r(),o("div",null,"Loading...")}const d=e(c,[["render",n]]);export{d as default};
