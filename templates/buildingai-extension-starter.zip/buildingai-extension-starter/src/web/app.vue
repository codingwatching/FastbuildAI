<script setup lang="ts">
import BuildingAIApp from "../../../../packages/web/buildingai-ui/app/app.vue";
</script>

<template>
    <BuildingAIApp />
</template>
