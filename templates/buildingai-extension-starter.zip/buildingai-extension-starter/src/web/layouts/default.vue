<script setup lang="ts">
import BuildingAIDefaultLayout from "../../../../../packages/web/buildingai-ui/app/layouts/default.vue";
</script>

<template>
    <BuildingAIDefaultLayout>
        <NuxtPage />
    </BuildingAIDefaultLayout>
</template>
