import { DataSource } from "@buildingai/db/typeorm";
import { Logger } from "@nestjs/common";

/**
 * Extension upgrade script for version 0.0.2
 *
 * Example upgrade logic for buildingai-simple-blog extension
 */
export class Upgrade {
    private readonly logger = new Logger(Upgrade.name);

    constructor(private readonly dataSource: DataSource) {}

    /**
     * Execute upgrade logic
     */
    async execute(): Promise<void> {
        this.logger.log("Starting upgrade to version 0.0.2");

        // There are upgrade logic for version 0.0.2

        this.logger.log("Upgrade to version 0.0.2 completed");
    }
}
